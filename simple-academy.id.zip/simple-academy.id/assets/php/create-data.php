<?php 
include 'koneksi.php';

$keahlian = $_POST['keahlian'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$tempat_lahir = $_POST['tempat_lahir'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$motivasi = $_POST['motivasi'];
$alamat = $_POST['alamat'];



mysqli_query($conn, "insert into tb_biodata_user values('','','$keahlian','$jenis_kelamin','$tempat_lahir','$tanggal_lahir','$motivasi','$alamat')");


header("Location: ../../dashboard.php");


?>