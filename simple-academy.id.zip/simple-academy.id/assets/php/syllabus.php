<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

<?php

include('../php/koneksi.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include('../PHPMailer/src/Exception.php');
include('../PHPMailer/src/PHPMailer.php');
include('../PHPMailer/src/SMTP.php');

$nama = $_POST['nama'];
$email = $_POST['email'];

$mysqli = mysqli_query($conn, "insert into syllabus values('','$nama','$email')");

if (($mysqli)) {
    $email_pengirim = 'simpleacademy.care@gmail.com';
    $nama_pengirim = 'Simple Academy.id';
    $email_penerima = $_POST['email'];
    $subject = 'Syllabus Full Stack Developer Simple Academy';

    $headers = 'MIME-Version: 1.0' . "\r\n";
    $header .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

    $pesan = "
    <!DOCTYPE html>
    <html lang='en'>
    
    <head>
        <meta charset='UTF-8'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Syllabus</title>
    
        <!-- CSS -->
        <style>
            .body {
                background-color: #f0f8ff;
                font-family: 'Poppins', sans-serif;
            }
    
            .box {
                margin: auto;
                margin-top: 50px;
                padding: 30px;
                font-size: 18px;
                width: 80%;
                height: auto;
                background-color: #fff;
            }
    
            .box2 {
                margin: auto;
                padding: 30px;
                font-size: 18px;
                width: 80%;
                height: auto;
                background-color: #0099da;
            }
    
            .btn {
                border: none;
                width: 100%;
                padding: 10px;
                font-weight: bold;
                border-radius: 5px;
            }
    
            .btn-primary {
                background-color: #0099da;
                color: #fff;
            }
    
            .btn:hover {
                cursor: pointer;
                background-color: #3ab1e4;
            }
    
            img {
                width: 300px;
            }
            .row{
                text-align: center;
            }
            
        </style>
    </head>
    
    <body class='body'>
        <div class='box'>
            <div class='row'>
                <img src='https://mikosetiawan.github.io/simple-academy.id/assets/img/logoSA2.svg' alt=''>
            </div>
            <div>
                <h3>Hallo!, <b>$nama</b></h3>
                <p>Download Syllabus Simple Academy.id</p>
                <h1>Syllabus Full Stack Developer</h1>
                <hr>
                <br>
                <p>Modul ini pengantar Program sistem pembelajaran Simple Academy, wong cilegon bisa IT kih tempate bisa
                    belajar bareng-bareng, semua bisa belajar disini dengan trainer terpilih dan berpengalaman dibidangnya
                </p>
                <br>
            </div>
            <p></p>
            <a href='https://mikosetiawan.github.io/syllabus/' target='_blank'><button class='btn btn-primary'>DOWNLOAD</button></a>
        </div>
    </body>
    
    
    </html>
    ";


    $mail = new PHPMailer();
    $mail->isSMTP();

    $mail->Host = 'smtp.gmail.com';
    $mail->Username = $email_pengirim;
    $mail->Password = 'bypzfbfwlymeogoz';
    $mail->Port = '465';
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'ssl';
    $mail->SMTPDebug = 2;


    $mail->setFrom($email_pengirim, $nama_pengirim);
    $mail->addAddress($email_penerima);
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $pesan;

    $send = $mail->send();
    if ($send) {
        echo "<h1>Email berhasil dikirim!</h1><a href='../../program.html'>Kembali ke Form</a>";
    } else {
        echo "<h1>Email gagal dikirim!</h1><a href='../../program.html'>Kembali ke Form</a>";
    }
    echo "<script>alert('Data berhasil dikirim!')</script>";
    echo "<script type='text/javascript'> document.location = '../../program.html'</script>";
}

?>