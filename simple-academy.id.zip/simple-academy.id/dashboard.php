<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: masuk.php");
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- LOGO -->
    <link rel="shortcut icon" href="assets/img/logoSA1.svg" type="image/x-icon">
    <title>Dashboard | Simple Academy.id</title>

    <!-- BOOSTRAP CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- ICON BOOSTRAP -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <!-- STYLE CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- CSS OAS ANIMATION -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>

<body class="bg-abu">

    <section>
        <!-- NAVBAR -->
        <ul class="nav nav-pills mb-3 nav-dash py-3 sticky-top" id="pills-tab" role="tablist">
            <a href="index.html"><img src="assets/img/logoSA3-svg.svg" class="logo-dashboard mx-5"></a>
            <li class="nav-item" role="presentation">
                <button class="nav-link active text-white" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Aktivitas Kelas</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-white" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Profile</button>
            </li>
        </ul>

        <!-- CONTENT DASHBOARD -->
        <div class="tab-content px-5 py-5" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                <!-- PROGRAM -->
                <section id="program">
                    <div class="row py-4">
                        <div class="col-sm-6">
                            <?php echo "<h4>Selamat Datang, " . $_SESSION['username'] . "!" . "</h4>"; ?>
                        </div>
                        <div class="col-sm-6">
                            <form class="d-flex">
                                <input class="form-control me-2" type="search" placeholder="Cari programu.." aria-label="Search">
                                <button class="btn btn-outline-primary" type="submit">Cari</button>
                            </form>
                        </div>
                    </div>
                    <div class="row shadow-sm rounded py-3 px-3 bg-white">
                        <div class="col-lg-12">
                            <h2>Program Simple Academy</h2>
                            <p>Daftar program booking pembelajaran</p>
                            <hr class="text-primary py-2">
                            <div class="row">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama lengkap</th>
                                                <th>Program Kelas</th>
                                                <th>Tipe Program</th>
                                                <th>Jadwal</th>
                                                <th colspan="2">Opsi</th>
                                                <th>Keterangan</th>
                                                <th>Sertifikat</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th>1</th>
                                                <td>Miko setiawan</td>
                                                <td>Full Stack Development</td>
                                                <td>Online</td>
                                                <td><img src="assets/img/calendar-fill.svg"> Senin, 22 Oktober 2023
                                                </td>
                                                <td><a href="kelas.html"><button class="btn btn-primary">Lanjutkan</button></a></td>
                                                <td><button class="btn btn-warning">Detail</button></td>
                                                <td><img src="assets/img/check.svg">Proses</td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <th>2</th>
                                                <td>Miko setiawan</td>
                                                <td>Design Grafis</td>
                                                <td>Offline</td>
                                                <td><img src="assets/img/calendar-fill.svg"> Sabtu, 01 September
                                                    2023</td>
                                                <td></td>
                                                <td><a href="detail.html" target="_blank"><button class="btn btn-warning">Detail</button></a></td>
                                                <td><img src="assets/img/check-all.svg">Selesai</td>
                                                <td>
                                                    <div class="embed-responsive embed-responsive-1by1">
                                                        <iframe src="assets/file/sampleCertificate.pdf" class="embed-responsive-item"></iframe>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div><br>
                    <div class="row shadow-sm bg-white rounded py-3 px-3">
                        <div class="col-lg-12">
                            <h2>Event Simple Academy</h2>
                            <p>Keikutsertaan event aktif yang diselenggarakan</p>
                            <hr class="text-primary py-2">
                            <div class="row">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama lengkap</th>
                                                <th>Event</th>
                                                <th>Tipe Program</th>
                                                <th>Jadwal</th>
                                                <th>Opsi</th>
                                                <th>Keterangan</th>
                                                <th>Sertifikat</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th>1</th>
                                                <td>Miko setiawan</td>
                                                <td>Full Stack Development</td>
                                                <td>Offline</td>
                                                <td><img src="assets/img/calendar-fill.svg"> Senin, 22 Oktober 2023
                                                </td>
                                                <td><a href="detail.html" target="_blank"><button class="btn btn-warning">Detail</button></a></td>
                                                <td><img src="assets/img/check-all.svg">Selesai</td>
                                                <td>
                                                    <div class="embed-responsive embed-responsive-1by1">
                                                        <iframe src="assets/file/sampleCertificate.pdf" class="embed-responsive-item"></iframe>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div><br>
                    <div class="row shadow-sm bg-white rounded py-3 px-3">
                        <div class="col-lg-12">
                            <h2>Bootcamp Simple Academy</h2>
                            <p>Keikutsertaan Bootcamp aktif yang diselenggarakan</p>
                            <hr class="text-primary py-2">
                            <div class="row">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama lengkap</th>
                                                <th>Event</th>
                                                <th>Tipe Program</th>
                                                <th>Jadwal</th>
                                                <th>Opsi</th>
                                                <th>Keterangan</th>
                                                <th>Sertifikat</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th>-</th>
                                                <td>-</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><img src="assets/img/calendar-fill.svg" hidden>-</td>
                                                <td>
                                                    -<a href="detail.html" target="_blank"><button class="btn btn-warning" hidden>Detail</button></a></td>
                                                <td><img src="assets/img/check-all.svg" hidden>-</td>
                                                <td>
                                                    -
                                                    <div class="embed-responsive embed-responsive-1by1" hidden>
                                                        <iframe src="assets/file/sertifikat-dicoding.pdf" class="embed-responsive-item"></iframe>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                <!-- PROFILE -->
                <section id="Profil">
                    <div class="row shadow-sm bg-white py-5 px-5 rounded">
                        <div class="col-lg-4 text-center">
                            <img src="assets/img/stadyCoures.png" class="w-75 rounded-circle shadow-sm my-3"><br>
                            <p class="image_upload">
                                <label for="userImage">
                                    <a class="btn btn-warning" rel="nofollow"><span class='bi bi-pencil-square text-black'></span> Upload Profil</a>
                                </label>
                                <input type="file" id="userImage" class="uploadFile">
                            </p>
                        </div>
                        <div class="col-lg-4 my-3">
                            <?php echo "<h2>" . $_SESSION['username'] . "</h2>"; ?>
                            <p>-</p>
                            <hr>
                            <p><b>Motivasi</b></p>
                            <p>-</p>
                            <hr>
                            <p><b>Jenis Kelamin</b></p>
                            <p>-</p>
                        </div>
                        <div class="col-lg-4">
                            <p><b>Tempat lahir</b></p>
                            <p>-</p>
                            <hr>
                            <p><b>Tanggal Lahir</b></p>
                            <p>-</p>
                            <hr>
                            <p><b>Alamat</b></p>
                            <p>-</p>
                        </div>
                    </div><br>
                    <div class="row py-5 px-5 shadow-sm bg-white rounded">
                        <h2>Lengkapi Data Diri</h2>
                        <p class="form-text">* Lengkapi data diri untuk menunjang pembelajaran</p>
                        <hr>
                        <div class="col-lg-6">
                            <form action="assets/php/create-data.php" method="POST">
                                <label class="py-2">Keahlian</label>
                                <select name="keahlian" class="form-select" required>
                                    <option value="">- Pilih -</option>
                                    <option value="Full Stack Developer">Full Stack Developer</option>
                                    <option value="Design Grafis">Design Grafis</option>
                                    <option value="Microsoft Office">Microsoft Office</option>
                                </select>
                                <label class="py-2">Jenis Kelamin</label>
                                <select name="jenis_kelamin" class="form-select" required>
                                    <option value="">- Pilih -</option>
                                    <option value="laki-laki">Laki-laki</option>
                                    <option value="perempuan">Perempuan</option>
                                </select>
                                <label class="py-2">Tempat Lahir</label>
                                <input type="text" name="tempat_lahir" id="" class="form-control" placeholder="Masukan.." required>
                                <label class="py-2">Tanggal Lahir</label>
                                <input type="date" name="tanggal_lahir" id="" class="form-control" placeholder="Masukan.." required>
                        </div>
                        <div class="col-lg-6">
                            <label class="py-2">Motivasi</label>
                            <textarea class="form-control" name="motivasi" id="" required placeholder="Masukan motivasi.."></textarea>
                            <label class="py-2">Alamat</label>
                            <textarea class="form-control" name="alamat" id="" required placeholder="Masukan Alamat.."></textarea><br>
                            <button class="btn btn-primary" type="submit">Simpan</button>
                            <a href="assets/php/keluar.php" class="btn btn-warning" onclick="return confirm('Yakin mau keluar?')">Keluar</a>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>




    <!-- BOOSTRAP JS -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- JQUERY -->
    <script src="assets/js/jquery-3.6.1.min.js"></script>
    <!-- MAIN JS -->
    <script src="assets/js/main.js"></script>
    <!-- JS AOS ANIMATION -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>

</html>