<?php

include 'assets/php/koneksi.php';

error_reporting(0);

session_start();

if (isset($_SESSION['username'])) {
    header("Location: masuk.php");
}

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $cpassword = md5($_POST['cpassword']);

    if ($password == $cpassword) {
        $sql = "SELECT * FROM users WHERE email='$email'";
        $result = mysqli_query($conn, $sql);
        if (!$result->num_rows > 0) {
            $sql = "INSERT INTO users (username, email, password)
                    VALUES ('$username', '$email', '$password')";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                echo "<script>alert('Selamat, Registrasi berhasil!')</script>";
                $username = "";
                $email = "";
                $_POST['password'] = "";
                $_POST['cpassword'] = "";
            } else {
                echo "<script>alert('Woops! Terjadi kesalahan.')</script>";
            }
        } else {
            echo "<script>alert('Woops! Email Sudah Terdaftar.')</script>";
        }
    } else {
        echo "<script>alert('Password Tidak Sesuai')</script>";
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- LOGO -->
    <link rel="shortcut icon" href="assets/img/logoSA1.svg" type="image/x-icon">
    <title>Gabung | Simple Academy.id</title>

    <!-- BOOSTRAP CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- STYLE CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <!-- CSS OAS ANIMATION -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>

<body>

    <section id="gabung" class="container-fluid bg-gradient-blue2">
        <div class="row">
            <div class="col-lg-6 py-5 px-5 text-center text-white">
                <a href="index.html"><img src="assets/img/logoSA3-svg.svg" class="w-25 logo-login"></a>
                <p>
                <h2>Berlangganan Bimbel IT di Kota Cilegon</h2>
                </p>
                <img src="assets/img/stadyCouresStart.png" class="w-100" data-aos="fade-up" data-aos-duration="1500">
            </div>
            <div class="col-lg-6 py-5 px-5">
                <div class="box-login py-5 px-5 rounded shadow">
                    <h2 class="text-center">Ayo Gabung dan belajar bareng disini!</h2>
                    <form action="" method="POST">
                        <div class="row">
                            <label class="py-2">Nama Lengkap</label>
                            <div class="input-group">
                                <input type="text" name="username" id="" class="form-control" placeholder="Masukan.." value="<?php echo $username; ?>" required>
                            </div>
                            <label class="py-2">E-mail</label>
                            <div class="input-group">
                                <input type="email" name="email" class="form-control" placeholder="Masukan.." value="<?php echo $email; ?>" required>
                            </div>
                            <label class="py-2">Password</label>
                            <div class="input-group">
                                <input id="pass" type="password" name="password" class="form-control" placeholder="Masukan.." value="<?php echo $_POST['password']; ?>" required maxlength="8">
                            </div>
                            <div class="form-text">Isi dengan 8 Karakter, gabungan huruf dan angka</div>
                            <label class="py-2">Konfirmasi Password</label>
                            <div class="input-group">
                                <input id="pass2" type="password" name="cpassword" class="form-control cpassword" placeholder="Masukan.." value="<?php echo $_POST['cpassword']; ?>" required maxlength="8">
                            </div>
                            <div class="form-text">Isi dengan 8 Karakter, gabungan huruf dan angka</div>
                            <p><input id="show" type="checkbox" class="form-check-input" id="exampleCheck1"> Show Password </p>
                            <button name="submit" class="btn btn-primary">Gabung</button>
                            <p></p>
                            <a href="index.html" class="btn btn-warning">Kembali</a>
                            <p class="py-2">Sudah punya akun<a href="masuk.php"> Login!</a> or | <a href="forget.html">Lupa
                                    Password?</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>



    <!-- EYE PASSWORD -->
    <script>
        var all = document.getElementById('show')
        var pass = document.getElementById('pass')
        var pass2 = document.getElementById('pass2')

        all.addEventListener('click', function() {
            if (all.checked) {
                pass.setAttribute('type', 'text'),
                    pass2.setAttribute('type', 'text')
            } else {
                pass.setAttribute('type', 'password'),
                    pass2.setAttribute('type', 'password')
            }
        })
    </script>

    <!-- BOOSTRAP JS -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- JQUERY -->
    <script src="assets/js/jquery-3.6.1.min.js"></script>
    <!-- MAIN JS -->
    <script src="assets/js/main.js"></script>
    <!-- JS AOS ANIMATION -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>

</html>