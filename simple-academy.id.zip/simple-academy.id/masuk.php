<?php

include 'assets/php/koneksi.php';

error_reporting(0);

session_start();

if (isset($_SESSION['username'])) {
    header("Location: dashboard.php");
}

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $sql);
    if ($result->num_rows > 0) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['username'] = $row['username'];
        header("Location: dashboard.php");
    } else {
        echo "<script>alert('Email atau password Anda salah. Silahkan coba lagi!')</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- LOGO -->
    <link rel="shortcut icon" href="assets/img/logoSA1.svg" type="image/x-icon">
    <title>Login | Simple Academy.id</title>

    <!-- BOOSTRAP CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <!-- STYLE CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- CSS OAS ANIMATION -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>

<body>
    <section id="gabung" class="container-fluid bg-gradient-blue2">
        <div class="row">
            <div class="col-lg-6 py-5 px-5 text-center text-white">
                <a href="index.html"><img src="assets/img/logoSA3-svg.svg" class="w-25 logo-login"></a>
                <p>
                <h2>Berlangganan Bimbel IT di Kota Cilegon</h2>
                </p>
                <img src="assets/img/stadyCouresStart.png" class="w-100" data-aos="fade-up" data-aos-duration="1500">
            </div>
            <div class="col-lg-6 py-5 px-5">
                <div class="box-login py-5 px-5 rounded shadow">
                    <h2 class="text-center">Gaskeun masuk dan semangat belajar!</h2>
                    <form action="" method="POST">
                        <div class="row">
                            <div class="mb-3">
                            <input type="text" name="id" class="form-control" value="<?php echo $id; ?>" hidden>
                                <label class="">Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Masukan.." value="<?php echo $email; ?>" required>
                            </div>
                            <label class="">Password</label>
                            <div class="input-group">
                                <span id="eye" class="input-group-text bi bi-eye-slash" id="basic-addon1" style="cursor: pointer;"></span>
                                <input id="password" type="password" name="password" class="form-control" placeholder="Masukan.." value="<?php echo $_POST['password']; ?>" required maxlength="8" aria-label="Username" aria-describedby="basic-addon1">
                            </div>
                            <div class="form-text">Isi dengan 8 Karakter, gabungan huruf dan angka</div>
                            <div class="py-3">
                                <button name="submit" class="btn btn-primary" style="width: 100%;">Masuk</button><br>
                                <p></p>
                                <a href="index.html" class="btn btn-warning" style="width: 100%;">Kembali</a>
                                <p class="py-2">Belum punya akun?<a href="gabung.php"> Gabung!</a> or | <a href="forget.html">Lupa
                                        Password?</a>
                                </p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>



    <!-- EYE PASSWORD -->
    <script>
        const passwordField = document.querySelector("#password");
        const eyeIcon = document.querySelector("#eye");

        eye.addEventListener("click", function() {
            this.classList.toggle("bi-eye");
            const type = passwordField.getAttribute("type") === "password" ? "text" : "password";
            passwordField.setAttribute("type", type);
        })
    </script>

    <!-- BOOSTRAP JS -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- JQUERY -->
    <script src="assets/js/jquery-3.6.1.min.js"></script>
    <!-- MAIN JS -->
    <script src="assets/js/main.js"></script>
    <!-- JS AOS ANIMATION -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>

</html>